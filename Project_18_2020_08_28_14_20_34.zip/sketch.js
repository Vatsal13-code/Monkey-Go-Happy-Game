var bananaImage, obstacleImage, obstacleGroup, scene, backImage,score,player,playerImage,banana,bananaGroup,obstacle, stone;
function preload () {
  playerImage = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png")
  backImage = loadImage("jungle.png")
  bananaImage = loadImage("banana.png")
  obstacleImage = loadImage("stone.png")
}

function setup() {
  createCanvas(400, 400);

  player = createSprite(30,350,20,20);
  player.addAnimation("runningPlayer",playerImage)
  scene = createSprite(400,400,400,400)
  scene.addImage("background",backImage)
  score = 0;
}

function draw() {
    background(220);
  if(keyDown("space")) {
  player.velocityY = -20
  }
  player.velocityY=player.velocityY+0.8;
  if(player.isTouching(bananaGroup)) {
   bananaGroup.destroyEach();
    score=score+2
  }
  if(player.isTouching(obstacleGroup)) {
   player.scale =  0.2 ;
  }
switch(score) {
  case 10: player.scale = 0.12;
        break
  case 20: player.scale = 0.14;
        break;
  case 30: player.scale=0.16;
        break;
  case 40: player.scale = 0.18;
        break
  default:break

}
    stroke("white");
  textSize(20);
  fill("white");
  text("Score" + score, 300,50)
    drawSprites();
    food();
    stone();
}



function food() {
  if(getframeCount % 80 == 0) {
    banana = createSprite(400, random(120,200),20,20)
    banana.addImage("banana",bananaImage)
    bananaGroup.add(banana)
    banana.velocityX = -7
  }
}
function rock() {
 if(getframeCount%100==0) {
  stone = createSprite(400,350,20,20)
  stone.addAnimation("rock",obstacleImage)
  stone.velocityX = -7
  obstacleGroup.add(stone)
 }
}